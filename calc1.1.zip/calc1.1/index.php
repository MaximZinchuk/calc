<?php
  session_start();
  //$_SESSION['1number'][];
  if(isset($_POST['one'])){
	$_SESSION['value']=$_SESSION['value'].'1';
  };
  if(isset($_POST['two'])){
	$_SESSION['value']=$_SESSION['value'].'2';
  };
  if(isset($_POST['three'])){
	$_SESSION['value']=$_SESSION['value'].'3';
  };
  if(isset($_POST['fourth'])){
	$_SESSION['value']=$_SESSION['value'].'4';
  };
  if(isset($_POST['five'])){
	$_SESSION['value']=$_SESSION['value'].'5';
  };
  if(isset($_POST['six'])){
	$_SESSION['value']=$_SESSION['value'].'6';
  };
  if(isset($_POST['seven'])){
	$_SESSION['value']=$_SESSION['value'].'7';
  };
  if(isset($_POST['eight'])){
	$_SESSION['value']=$_SESSION['value'].'8';
  };
  if(isset($_POST['nine'])){
	$_SESSION['value']=$_SESSION['value'].'9';
  };
  if(isset($_POST['ziro'])){
	if($_SESSION['value']>0){
	  $_SESSION['value']=$_SESSION['value'].'0';
	}
  };
  if(isset($_POST['clear'])){
	session_destroy();
  };
  if(isset($_POST['plus'])){
  	if($_SESSION['notresulted']==0){
	  $_SESSION['old']=$_SESSION['value'];
	  $_SESSION['value']='';
	  $_SESSION['notresulted']=1;
	};
	};
	if(isset($_POST['minus'])){
  	if($_SESSION['notresulted']==0){
	  $_SESSION['old']=$_SESSION['value'];
	  $_SESSION['value']='';
	  $_SESSION['notresulted']=2;
	};
	};
	if(isset($_POST['division'])){
  	if($_SESSION['notresulted']==0){
	  $_SESSION['old']=$_SESSION['value'];
	  $_SESSION['value']='';
	  $_SESSION['notresulted']=3;
	};
	};
	if(isset($_POST['multiplication'])){
  	if($_SESSION['notresulted']==0){
	  $_SESSION['old']=$_SESSION['value'];
	  $_SESSION['value']='';
	  $_SESSION['notresulted']=4;
	};
	};
    if(isset($_POST['result'])){
	if($_SESSION['notresulted']==1){
      $_SESSION['notresulted']=0;
	  $_SESSION['value']=$_SESSION['old']+$_SESSION['value'];
	  $_SESSION['old']='';
    };
	if($_SESSION['notresulted']==2){
      $_SESSION['notresulted']=0;
	  $_SESSION['value']=$_SESSION['old']-$_SESSION['value'];
	  $_SESSION['old']='';
    };
	if($_SESSION['notresulted']==3){
      $_SESSION['notresulted']=0;
	  $_SESSION['value']=$_SESSION['old']/$_SESSION['value'];
	  $_SESSION['old']='';
    };
	if($_SESSION['notresulted']==4){
      $_SESSION['notresulted']=0;
	  $_SESSION['value']=$_SESSION['old']*$_SESSION['value'];
	  $_SESSION['old']='';
    };
  };
?>

<!DOCTYPE html>
<html lang="ru">
<head>
  <meta http-equiv="Content-Type" content="text/html" charset="UTF-8">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <title>Пишем калькулятор</title>
</head>
<body>
  <form action="" method="POST">
    <h4><i>Калькулятор версия 1.0</i></h4>
    <div class="result">
	  <input type="text" name="input" id="_input" value="<?php
			echo $_SESSION['value'];;
	  ?>" placeholder="0">
	  <input type="submit" name="clear" id="clear" value="CE">
	</div>
	<div class="keyboard">
	  <div class="num">
	    <p>
		  <input type="submit" name="one" id="num" value="1">
		  <input type="submit" name="two" id="num" value="2">
		  <input type="submit" name="three" id="num" value="3">
		</p>
		<p>
		  <input type="submit" name="fourth" id="num" value="4">
		  <input type="submit" name="five" id="num" value="5">
		  <input type="submit" name="six" id="num" value="6">
		</p>
		<p>
		  <input type="submit" name="seven" id="num" value="7">
		  <input type="submit" name="eight" id="num" value="8">
		  <input type="submit" name="nine" id="num" value="9">
		</p>
		<p>
		  <input type="submit" name="ziro" id="num" value="0">
		  <input type="submit" name="result" id="result_butt" value="=">
		</p>
	  </div>
	  <div class="operation">
	    <p><input type="submit" name="plus" id="operation" value="+"></p>
		<p><input type="submit" name="minus" id="operation" value="-"></p>
		<p><input type="submit" name="multiplication" id="operation" value="*"></p>
		<p><input type="submit" name="division" id="operation" value="/"></p>
	  </div>
	</div>
  </form>
</body>
</html>